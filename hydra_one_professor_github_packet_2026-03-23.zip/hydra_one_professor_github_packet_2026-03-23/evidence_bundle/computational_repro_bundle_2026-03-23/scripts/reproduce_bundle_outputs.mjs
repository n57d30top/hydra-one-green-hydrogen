import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

function formatNumber(value) {
  return Number(value).toFixed(6).replace(/0+$/, '').replace(/\.$/, '.0');
}

function buildHydraOneCifText(input) {
  const lines = [
    `data_${input.dataLabel}`,
    `_chemical_name_common '${input.commonName}'`,
    `_chemical_formula_sum '${input.formula}'`,
    `_space_group_name_H-M_alt '${input.symmetrySummary.spaceGroup}'`,
    `_symmetry_cell_setting '${input.symmetrySummary.crystalSystem}'`,
    `_cell_length_a ${formatNumber(input.unitCell.a)}`,
    `_cell_length_b ${formatNumber(input.unitCell.b)}`,
    `_cell_length_c ${formatNumber(input.unitCell.c)}`,
    `_cell_angle_alpha ${formatNumber(input.unitCell.alpha)}`,
    `_cell_angle_beta ${formatNumber(input.unitCell.beta)}`,
    `_cell_angle_gamma ${formatNumber(input.unitCell.gamma)}`,
    '_exptl_special_details',
    ';',
    ...input.details,
    ';',
    'loop_',
    '_atom_site_label',
    '_atom_site_type_symbol',
    '_atom_site_fract_x',
    '_atom_site_fract_y',
    '_atom_site_fract_z',
    '_atom_site_occupancy',
    ...input.atomSites.map((site) => (
      `${site.label} ${site.element} ${formatNumber(site.fractX)} ${formatNumber(site.fractY)} ${formatNumber(site.fractZ)} ${formatNumber(site.occupancy)}`
    )),
  ];
  return `${lines.join('\n')}\n`;
}

function sha256(text) {
  return createHash('sha256').update(text, 'utf8').digest('hex');
}

function parseArgs(argv) {
  const parsed = {
    bundle: null,
  };

  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (token === '--bundle') {
      parsed.bundle = argv[index + 1];
      index += 1;
    }
  }

  return parsed;
}

async function ensureDir(dirPath) {
  await fs.mkdir(dirPath, { recursive: true });
}

async function readJson(filePath) {
  return JSON.parse(await fs.readFile(filePath, 'utf8'));
}

async function main() {
  const scriptPath = fileURLToPath(import.meta.url);
  const scriptDir = path.dirname(scriptPath);
  const defaultBundleDir = path.resolve(scriptDir, '..');
  const args = parseArgs(process.argv.slice(2));
  const bundleDir = path.resolve(args.bundle || defaultBundleDir);
  const manifestPath = path.join(bundleDir, 'manifest.json');
  const manifest = await readJson(manifestPath);

  const outDir = path.join(bundleDir, 'reproduced');
  const outSeedDir = path.join(outDir, 'structure-seeds');
  const outCifDir = path.join(outDir, 'cif');
  await ensureDir(outSeedDir);
  await ensureDir(outCifDir);

  const checksumLines = [];

  for (const candidate of manifest.candidates) {
    const seedJsonPath = path.join(bundleDir, candidate.seedJsonPath);
    const seedCifPath = path.join(bundleDir, candidate.seedCifPath);
    const relaxationJsonPath = path.join(bundleDir, candidate.relaxationJsonPath);
    const finalCifPath = path.join(bundleDir, candidate.cifArtifactPath);

    const seed = await readJson(seedJsonPath);
    const relaxation = await readJson(relaxationJsonPath);

    const generatedSeedCif = buildHydraOneCifText({
      dataLabel: `${candidate.label}_seed`,
      commonName: `${candidate.label} surrogate seed`,
      formula: seed.surrogateFormula,
      symmetrySummary: seed.symmetrySummary,
      unitCell: seed.unitCell,
      atomSites: seed.atomSites,
      details: [
        'Hydra One surrogate structure seed.',
        `Campaign ref: ${seed.campaignRef}`,
        `Target dossier ref: ${seed.targetDossierRef}`,
        `Candidate ID: ${seed.candidateId}`,
        `Material family: ${seed.materialFamily}`,
        `Composition summary: ${seed.compositionSummary}`,
        `Source ref: ${seed.sourceRef}`,
        'This seed is a family-level surrogate template, not a wet-lab validated crystal structure.',
      ],
    });
    const generatedFinalCif = buildHydraOneCifText({
      dataLabel: `${candidate.label}_relaxed`,
      commonName: `${candidate.label} surrogate relaxed structure`,
      formula: relaxation.surrogateFormula,
      symmetrySummary: relaxation.symmetrySummary,
      unitCell: relaxation.unitCell,
      atomSites: relaxation.atomSites,
      details: [
        'Hydra One advisory surrogate structure relaxation.',
        `Campaign ref: ${relaxation.campaignRef}`,
        `Target dossier ref: ${relaxation.targetDossierRef}`,
        `Candidate ID: ${relaxation.candidateId}`,
        `Seed ref: ${relaxation.seedRef}`,
        `Material family: ${relaxation.materialFamily}`,
        `Composition summary: ${relaxation.compositionSummary}`,
        `Execution mode: ${relaxation.executionMode}`,
        `Backend mode: ${relaxation.backendMode}`,
        'Truth class: advisory_surrogate',
        'This CIF is a deterministic, provenance-aware surrogate relaxation built from a family template.',
        'It is not a DFT- or wet-lab-backed crystal truth claim.',
        'Hydra One remains advisory-only and does not authorize wet-lab or partner-lab handoff.',
      ],
    });

    const sourceSeedCif = await fs.readFile(seedCifPath, 'utf8');
    const sourceFinalCif = await fs.readFile(finalCifPath, 'utf8');

    if (generatedSeedCif !== sourceSeedCif) {
      throw new Error(`seed_cif_mismatch:${candidate.seedCifPath}`);
    }
    if (generatedFinalCif !== sourceFinalCif) {
      throw new Error(`final_cif_mismatch:${candidate.cifArtifactPath}`);
    }

    const writtenSeedPath = path.join(outSeedDir, path.basename(candidate.seedCifPath));
    const writtenFinalPath = path.join(outCifDir, path.basename(candidate.cifArtifactPath));
    await fs.writeFile(writtenSeedPath, generatedSeedCif, 'utf8');
    await fs.writeFile(writtenFinalPath, generatedFinalCif, 'utf8');

    checksumLines.push(`${sha256(generatedSeedCif)}  reproduced/structure-seeds/${path.basename(candidate.seedCifPath)}`);
    checksumLines.push(`${sha256(generatedFinalCif)}  reproduced/cif/${path.basename(candidate.cifArtifactPath)}`);

    console.log(`verified ${candidate.label}`);
  }

  await fs.writeFile(path.join(outDir, 'SHA256SUMS.txt'), `${checksumLines.join('\n')}\n`, 'utf8');
  console.log(`wrote ${outDir}`);
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
});
