# Reproduce

This bundle was generated from SovrynClean revision `7c11183f0ac43d7a8bb79b11452cdb6375e02113`.

The bundle runner was validated locally with:

- `node v24.13.1`
- `npm 11.8.0`

## What Is Reproducible Here

Using the included JSON provenance files, others can re-materialize the exact same seed CIFs and final CIFs and verify them against the files shipped in this bundle.

## What Is Not Reproducible Here

This bundle does not prove real crystal truth or physical manufacturability:

- the final structures are deterministic surrogate relaxations derived from family templates
- the bundle does not contain solver-backed, DFT-backed, or wet-lab validation
- it does not provide a sufficient basis for a physical synthesis claim or a scientific truth claim on its own

## GitHub Quick Start

If this directory is published as its own GitHub repository or as a folder inside a repository:

```bash
cd computational_repro_bundle_2026-03-23
node scripts/reproduce_bundle_outputs.mjs
```

Expected result:

- `reproduced/structure-seeds/*.cif` is written
- `reproduced/cif/*.cif` is written
- `reproduced/SHA256SUMS.txt` is generated
- the script fails if any bundled CIF cannot be reconstructed exactly from the JSON provenance files

## Repo-Linked Reproduction

If the bundle is kept inside a SovrynClean checkout, use the revision above and run:

```bash
git checkout 7c11183f0ac43d7a8bb79b11452cdb6375e02113
node outputs/runtime/hydra-one/escalation/computational_repro_bundle_2026-03-23/scripts/reproduce_bundle_outputs.mjs --bundle outputs/runtime/hydra-one/escalation/computational_repro_bundle_2026-03-23
```

## Meaning of the Limits

`computational reproduction` here means:

- reading the same JSON inputs
- reconstructing the same `.cif` files from those inputs
- recovering the same bytes, unit-cell parameters, and fractional coordinates

`scientific or physical reproduction` would require more:

- real or solver-validated starting structures
- a clearly specified simulation or DFT stack with all parameters
- experimental synthesis and characterization steps
- independent confirmation that the real material actually adopts the claimed structure
