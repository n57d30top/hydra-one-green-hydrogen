# Hydra One Computational Repro Bundle

Created on 2026-03-23 for four Hydra One candidates from campaign `hydra-one-campaign:4292e1d9-f2d8-44f9-8f0e-cecb7fa360b2`.

## Purpose

This bundle is intended to let external reviewers inspect and reproduce the local, repo-internal Hydra One structure model:

- load the same seed structures
- trace the same surrogate relaxations
- import and compare the same final `.cif` artifacts

## Important Limits

- Hydra One remains advisory-only.
- These structures are family-based surrogate relaxations, not solver-backed or DFT-confirmed crystal truth.
- No wet-lab authorization, no partner-lab authorization, and no basis for strong performance claims is implied.
- The `.cif` files are suitable for computational handoff, visualization, and internal comparison, but not as a standalone basis for physical synthesis or scientific reproducibility claims.

## Contents

- `cif/`
  Final surrogate CIF exports for each candidate.
- `structure-seeds/`
  Seed CIFs and seed JSON files used to start the relaxations.
- `structure-relaxations/`
  Relaxation JSON files with unit-cell parameters, atom positions, provenance, and safety truth.
- `context/`
  Campaign, readiness-review, and research-packet context for interpretation.
- `manifest.json`
  Machine-readable mapping between candidates and files.

## Reproduction Chain

1. Identify the candidate in `context/hydra-one-campaign_4292e1d9-f2d8-44f9-8f0e-cecb7fa360b2.json`.
2. Determine the matching seed from `manifest.json` or `structure-relaxations/*.json` via `seedRef`.
3. Load the seed CIF and seed JSON from `structure-seeds/`.
4. Read the relaxation JSON from `structure-relaxations/`.
5. Compare the final structure in `cif/` using `cifArtifactPath`.

## Included Candidates

- Variant 15: `mn_fe_oxyhydroxide`
- Variant 14: `co_free_spinel_oxide`
- Variant 13: `ni_fe_layered_hydroxide`
- Variant 3: `ni_mo_nitride`
